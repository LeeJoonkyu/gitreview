def is_evenly_divisible(number):
    if number % 2 == 0:
        return True
    else:
        return False

print(is_evenly_divisible(3))
print(is_evenly_divisible(7))
print(is_evenly_divisible(8))
